# GeniusCash AI
Description complète du projet avec toutes ses fonctionnalités.